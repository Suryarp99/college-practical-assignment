// WAP to print days of week.

#include<stdio.h>

void main(){
    int n;
    printf("Enter number: ");
    scanf("%d", &n);
    
    switch (n)
    {
    case 1:
        printf("Monday");
        break;
    case 2:
        printf("Monday");
        break;
    case 3:
        printf("Monday");
        break;
    case 4:
        printf("Monday");
        break;
    case 5:
        printf("Monday");
        break;
    case 6:
        printf("Monday");
        break;
    case 7:
        printf("Monday");
        break;
    
    default:
        printf("Enter a day between 1-7");
        break;
    }

}