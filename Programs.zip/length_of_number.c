// WAP to calculate the length of the user given number.

#include<stdio.h>
 void main(){
    int a, num;
    printf("Enter a number: ");
    scanf("%d", &num);
    a = printf("%d\n", num);
    printf("%d", a-1);
 }
